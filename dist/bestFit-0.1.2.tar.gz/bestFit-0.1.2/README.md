## bestFit
Simple wrapper to plot the best fit line for a given set of coordinates.

Docs: (check back later)