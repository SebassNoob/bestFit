## bestFit
Simple wrapper to plot the best fit line for a given set of coordinates.

Installation:
``pip install bestFit``

Docs: https://bestfit.readthedocs.io/en/latest/
