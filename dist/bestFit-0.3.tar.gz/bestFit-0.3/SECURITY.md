# Security Policy

## Supported Versions

These are the versions which are currently supported with security updates

| Version | Supported          |
| ------- | ------------------ |
| 0.3.x   | :white_check_mark: |
| 0.2.1   | ✅                |
| < 0.2.1  | :x:                |


## Reporting a Vulnerability

Please report vulerablilities by opening a new issue and describe the steps to reproduce the vulerability.
